<?php
    class Conexion{
        public $ipServidor;
        public $puerto;
        public $usuario;
        public $contrasena;
    }
?>